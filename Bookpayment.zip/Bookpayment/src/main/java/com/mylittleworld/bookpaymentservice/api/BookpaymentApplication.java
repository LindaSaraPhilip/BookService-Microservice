package com.mylittleworld.bookpaymentservice.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class BookpaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookpaymentApplication.class, args);
	}

}
