package com.mylittleworld.bookpaymentservice.api.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name="BookPayment")

public class Payment {
	@Id
	@GeneratedValue
	private int payId;
	private String transactionId;
	private int orderId;
	private double amount;
	public Payment()
	{
		
	}
	public Payment(int payId, String transactionId, int orderId, double amount, String paymentStatus) {
		super();
		this.payId = payId;
		this.transactionId = transactionId;
		this.orderId = orderId;
		this.amount = amount;
		this.paymentStatus = paymentStatus;
	}
	public int getOrderid() {
		return orderId;
	}
	public void setOrderid(int orderId) {
		this.orderId = orderId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getPayId() {
		return payId;
	}
	public void setPayId(int payId) {
		this.payId = payId;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	private String paymentStatus;

}
