package com.mylittleworld.bookpaymentservice.api.Service;



import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mylittleworld.bookpaymentservice.api.Model.Payment;
import com.mylittleworld.bookpaymentservice.api.Repo.PaymentRepo;



@Service
public class PaymentService {
	@Autowired
	private PaymentRepo repo;
	public Payment doPay( Payment pay)
	{
		pay.setTransactionId(UUID.randomUUID().toString());
		pay.setPaymentStatus(payProcessing());
		return repo.save(pay);
	}
	public String payProcessing()
	{
		return new Random().nextBoolean()?"Success":"Failed";
	}
public Payment findPaymentHistoryByOrderId (int orderId)
{
	return repo.findByOrderId(orderId);
	
}
}