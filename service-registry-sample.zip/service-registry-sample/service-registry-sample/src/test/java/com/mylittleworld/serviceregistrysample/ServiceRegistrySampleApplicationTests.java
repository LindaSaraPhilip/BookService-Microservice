package com.mylittleworld.serviceregistrysample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistrySampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
